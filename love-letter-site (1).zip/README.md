
# Love Letter Site

This is a tiny, single-file website that types out a heartfelt letter with floating hearts.

## Quick start
1. Open `index.html` in your browser to see it.
2. Edit the `message` string inside the `<script>` tag to customize the letter.
3. To share it online, host it with GitHub Pages (instructions below).

## GitHub Pages (Project Site)
1. Create a new repository on GitHub (e.g., `love-letter-site`). Keep it **Public**.
2. Upload `index.html` to the repository (drag-and-drop via **Add file → Upload files**).
3. Commit (save) the changes.
4. Go to **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **Deploy from a branch**.
6. Set **Branch** to `main` and **Folder** to `/ (root)`. Click **Save**.
7. Your site will be available at `https://<your-username>.github.io/<repository-name>/`.

## Customization ideas
- Change the gradient colors in the `:root` CSS section.
- Adjust the `typingSpeed` (in milliseconds).
- Replace the heart symbol with any emoji you like.
